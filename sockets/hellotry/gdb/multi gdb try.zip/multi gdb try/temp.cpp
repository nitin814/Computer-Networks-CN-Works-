
include <bits/stdc++.h>
using namespace std;
int main ()
{
    int num1,num2;
    cin>>num1;
    cin>>num2;

    cout<<num1+num2<<endl;
    cout<<num1*num2<<endl;
}


